<?php echo e($slot); ?>

<?php /**PATH D:\xampp7.2\htdocs\hotelmanagement\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>