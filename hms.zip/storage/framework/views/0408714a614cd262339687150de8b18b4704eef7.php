<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php echo e(asset('front/styles/style.css')); ?>">
    <!-- Material Design for Bootstrap fonts and icons -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons">

    <!-- Material Design for Bootstrap CSS -->
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-material-design@4.1.1/dist/css/bootstrap-material-design.min.css" integrity="sha384-wXznGJNEXNG1NFsbm0ugrLFMQPWswR3lds2VeinahP8N0zJw9VWSopbjv2x7WCvX" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/css?family=Questrial|Roboto&display=swap" rel="stylesheet">
    
    <title>Hotel Management</title>
  </head>
  <body>
  
    <header>
      <nav class="navbar navbar-expand-lg desktop">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse container" id="navbarTogglerDemo01">
          <a class="navbar-brand" href="#">HOTELCRM</a>
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">List Space <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Solutions</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Join</a>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <button class="btn  my-2 my-sm-0 btn btn-raised btn-primary" type="submit">Login</button>
          </form>
        </div>
      </nav>
    </header>

    <div class="mobmenupart">
    <h2>HotelCRM</h2>
      <div id="mobmenu" class="overlay">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          <div class="overlay-content">
            <a href="#">List Space</a>
            <a href="#">Solutions</a>
            <a href="#">Join</a>
            <a href="#">Login</a>
          </div>
        </div>
        
        
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
        
        </div>

    <div class="sectionbanner">
      <div class="bannersection">
        <div class="bannercontent">

          <div class="typewriter">
            <h1>Discover spaces.</h1>
          </div>
          
          <div class="formsection">
          <form>
            <div class="form-group">
              <input type="text" class="form-control" id="inputAddress" placeholder="Meeting City">
            </div>

            <div class="form-row">
              <div class="form-group col-md-6">
                <input type="text" class="form-control" id="inputEmail4" placeholder="No. of people">
              </div>
              <div class="form-group col-md-6">
                <input type="text" class="form-control" id="inputPassword4" placeholder="Duration">
              </div>
            </div>
            
            <div class="form-row">
              <div class="form-group col-md-6">
                <input type="text" class="form-control" id="inputEmail4" placeholder="Start date">
              </div>
              <div class="form-group col-md-6">
                <input type="text" class="form-control" id="inputPassword4" placeholder="End date">
              </div>
            </div>
            <button type="button" class="btn btn-raised spacebtn">Find Space</button>
          </form>
        </div>

        </div>
        <div class="bannerimg">
          <img src="<?php echo e(asset('front/images/bannerimage.jpg')); ?>" />
        </div>
      </div>

    </div>

      <section class="sectiontwo">
      <div class="badgepart">
        <span class="badge badge-pill badge-primary">Innovation</span>
      </div>
        <div class="details">
          <h3>Join the digital transformation of events</h3>
          <p>One platform catering for all your meeting 
          and events from a 5 person boardroom for one hour to a 200 person conference.</p>
        </div>
      
        <div class="container cardflex">
          
          <div class="cards">
            <div class="card">
              <img src="<?php echo e(asset('front/images/meetingpic.jpg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Small meetings</h5>
                <p class="card-text">Book smaller spaces online
                  on-demand by the hour or day.</p>
                <a href="#" class="btn btn-primary">Book online </a>
              </div>
            </div>
          </div>
          <div class="cards">
            <div class="card">
              <img src="<?php echo e(asset('front/images/accomodationpic.jpg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Conference & events</h5>
                <p class="card-text">Let venues bid for your larger events. Get multiple quotes, 
                  compare and book direct.</p>
                <a href="#" class="btn btn-primary">Select Venues </a>
              </div>
            </div>
          </div>
          <div class="cards">
            <div class="card">
              <img src="<?php echo e(asset('front/images/conferencepic.jpg')); ?>" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">Group accommodation</h5>
                <p class="card-text">Hotels compete for your groups by adding competitive offers online via RFP</p>
                <a href="#" class="btn btn-primary">Select Hotels </a>
              </div>
            </div>
          </div>

        </div>
      </section>

      <section class="container">
        <div class="globalsection">
        <div class="flexpart">
          <div class="textpart margintop">
            <div class="badgepart">
              <span class="badge2 badge-pill badge-primary">Global</span>
            </div>
            <h1>Over 137,000 spaces around the world.</h1>

            <p>Discover a wide range of venues suitable 
            for all your meeting needs from major hotel brands to independent alternative spaces</p>

            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Hotels</p>
            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Alternative spaces</p>
            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Conference venues</p>
            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Coworking spaces</p>

          </div>
          <div class="imgpart">

            <div class="row">
              <div class="col-md-6">
                <img class="img1" src="<?php echo e(asset('front/images/image11.jpg')); ?>" />
              </div>
              <div class="col-md-6">
                <img class="img2" src="<?php echo e(asset('front/images/image22.jpg')); ?>" />
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <img class="img3" src="<?php echo e(asset('front/images/image44.jpg')); ?>" />
              </div>
              <div class="col-md-6 mt">
                <img class="img4" src="<?php echo e(asset('front/images/image33.jpg')); ?>" />
              </div>
            </div>

          </div>
        </div>
        </div>
      </section>
 
      <hr>

         <section class="container">
        <div class="globalsection">
        <div class="flexpart">
          <div class="textpart">
            <div class="badgepart">
              <span class="badge2 badge-pill badge-primary">Business</span>
            </div>
            <h1>Business account:
              Track your meetings expenditure.</h1>

            <p>With a business account your organisation can easily track global meeting expenditure and savings.
               The platform includes:</p>

            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Booking approvals</p>
            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Live reporting</p>
            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Preferred hotels</p>
            <p><img src="<?php echo e(asset('front/images/check.png')); ?>" />Increased savings</p>

          </div>
          <div class="imgpart">

            <div class="row">
              <div class="col-md-12">
                <img class="img5" src="<?php echo e(asset('front/images/mainpic.png')); ?>" />
              </div>
             
            </div>
         

          </div>
        </div>
        </div>
      </section>

      <section class="sectiontwo uniqueplace">
        <div class="badgepart">
          <span class="badge badge-pill badge-primary">UNIQUE VENUES</span>
        </div>
          <div class="details">
            <h3>Unique spaces ready to host your events</h3>
            <p>Discover thousands of alternative meeting spaces around the world.</p>
          </div>
        
          <div class="container cardflex">
            <div class="row">
            <div class="cards">
              <div class="card">
                <a href="#">
                <img src="<?php echo e(asset('front/images/meetingpic.jpg')); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Paris.Art Galleries</h5>
                  <p class="card-text">Deskeo Saint-Honore</p>
                </div>
              </a>
              </div>
            </div>
            <div class="cards">
              <div class="card">
                <a href="#">
                <img src="<?php echo e(asset('front/images/accomodationpic.jpg')); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Amsterdam.Museum</h5>
                  <p class="card-text">Eye Filmmuseum</p>
                </div>
                </a>
              </div>
            </div>
            <div class="cards">
              <div class="card">
                <a href="#">
                <img src="<?php echo e(asset('front/images/conferencepic.jpg')); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">San Francisco </h5>
                  <p class="card-text"> Eco-Systm San Francisco</p>
                 
                </div>
                </a>
              </div>
            </div>
            </div>
            <div class="row">
              <div class="cards">
                <div class="card">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/meetingpic.jpg')); ?>" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">London.Stadium</h5>
                    <p class="card-text">London Stadium.</p>
                  
                  </div>
                  </a>
                </div>
              </div>
              <div class="cards">
                <div class="card">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/accomodationpic.jpg')); ?>" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">Berlin.Studio</h5>
                    <p class="card-text">Village Berlin</p>
                   
                  </div>
                  </a>
                </div>
              </div>
              <div class="cards">
                <div class="card">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/conferencepic.jpg')); ?>" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">Sydney.Business Centers</h5>
                    <p class="card-text">Stone & Chalk Sydney</p>
                
                  </div>
                  </a>
                </div>
              </div>
              </div>
          </div>
        </section>

        <section class="container">
          <div class="explorecities">
            <div class="badgepart">
              <span class="badge badge-pill badge-primary">CITIES</span>
            </div>
              <div class="details">
                <h3>Explore our top cities</h3>
                <p>Discover 137,000 unique spaces</p>
              </div>
              <div class="explore">
                <div class="city">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/image11.jpg')); ?>" />
                  <div class="detailcity">
                    <h2>London</h2>
                    <h5>
                      Explore 4,954 meeting venues in the Capital city of the England
                  </h5>
                  <p>$200 per day</p>
                  </div>
                </a>
                </div>
                <div class="city">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/image4.jpg')); ?>" />
                  <div class="detailcity">
                    <h2>London</h2>
                    <h5>
                      Explore 4,954 meeting venues in the Capital city of the England
                  </h5>
                  <p>$200 per day</p>
                  </div>
                </a>
                </div>
                <div class="city">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/image33.jpg')); ?>" />
                  <div class="detailcity">
                    <h2>London</h2>
                    <h5>
                      Explore 4,954 meeting venues in the Capital city of the England
                  </h5>
                  <p>$200 per day</p>
                  </div>
                </a>
                </div>
              </div>
              <div class="explore">
                <div class="city">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/image5.jpg')); ?>" />
                  <div class="detailcity">
                    <h2>London</h2>
                    <h5>
                      Explore 4,954 meeting venues in the Capital city of the England
                  </h5>
                  <p>$200 per day</p>
                  </div>
                </a>
                </div>
                <div class="city">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/image22.jpg')); ?>" />
                  <div class="detailcity">
                    <h2>London</h2>
                    <h5>
                      Explore 4,954 meeting venues in the Capital city of the England
                  </h5>
                  <p>$200 per day</p>
                  </div>
                </a>
                </div>
                <div class="city">
                  <a href="#">
                  <img src="<?php echo e(asset('front/images/image5.jpg')); ?>" />
                  <div class="detailcity">
                    <h2>London</h2>
                    <h5>
                      Explore 4,954 meeting venues in the Capital city of the England
                  </h5>
                  <p>$200 per day</p>
                  </div>
                </a>
                </div>
              </div>
          </div>
        </section>

        <section class="container">
          <div class="footer">
            <div class="part1">
              <h1 class="logo">HotelCRM</h1>
              <p>Helping the world meet</p>
            </div>
            <div class="part2">
              <h3>About Us</h3>
              <p><a href="#">Team</a></p>
              <p><a href="#">News</a></p>
              <p><a href="#">Blog</a></p>
              <p><a href="#">Careers</p>
              <p><a href="#"> Contact Us</a></p>
            </div>
            <div class="part2">
              <h3>Meeting Organiser</h3>
              <p><a href="#">How it works</a></p>
              <p><a href="#">Business account</a></p>
              <p><a href="#">White Paper</a></p>
            </div>
            <div class="part2">
              <h3>Hotel and Organiser</h3>
              <p><a href="#">List Space</a></p>
              <p><a href="#">Premium Listing</a></p>
              <p><a href="#">Booking Engine</a></p>
            </div>
            <div class="part2">
              <h3>Legal </h3>
              <p><a href="#">Terms</a></p>
              <p><a href="#">Privacy</a></p>
            </div>
          </div>
        </section>

    <!-- JavaScript -->
    <script src="<?php echo e(asset('front/js/style.js')); ?>"></script>
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/popper.js@1.12.6/dist/umd/popper.js" integrity="sha384-fA23ZRQ3G/J53mElWqVJEGJzU0sTs+SvzG8fXVWP+kJQ1lwFAOkcUOysnlKJC33U" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/bootstrap-material-design@4.1.1/dist/js/bootstrap-material-design.js" integrity="sha384-CauSuKpEqAFajSpkdjv3z9t8E7RlpJ1UP0lKM/+NdtSarroVKu069AlsRPKkFBz9" crossorigin="anonymous"></script>
    <script>$(document).ready(function() { $('body').bootstrapMaterialDesign(); });</script>

    <script>
      function openNav() {
        document.getElementById("mobmenu").style.width = "100%";
      }
      
      function closeNav() {
        document.getElementById("mobmenu").style.width = "0%";
      }
      </script>
  </body>
</html><?php /**PATH D:\xampp7.2\htdocs\hotelmanagement\resources\views/index.blade.php ENDPATH**/ ?>