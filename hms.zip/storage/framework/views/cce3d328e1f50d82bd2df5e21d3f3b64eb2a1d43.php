        <footer class="footer">
            © 2019 Eliteadmin by themedesigner.in
        </footer>
<?php /**PATH D:\xampp7.2\htdocs\hotelmanagement\resources\views/super_admin/includes/footer.blade.php ENDPATH**/ ?>